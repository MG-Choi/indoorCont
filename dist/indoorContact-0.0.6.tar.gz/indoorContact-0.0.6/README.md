# indoorCont
ABM simulation for indoor contact


## License
indoorContact / version 0.0.7
- install:

```python
!pip install indoorContact
```

## Usage (Run simulation and export movie clip)

### 1. add space from data or make space

``` python
import indoorContact as ic




```






